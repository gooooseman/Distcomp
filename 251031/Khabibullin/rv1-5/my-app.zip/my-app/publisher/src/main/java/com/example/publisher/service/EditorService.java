package com.example.publisher.service;

import com.example.publisher.dto.EditorRequestTo;
import com.example.publisher.dto.EditorResponseTo;
import com.example.publisher.model.Editor;
import com.example.publisher.repository.EditorRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EditorService {
    private final EditorRepository editorRepository;
    private final EditorMapper editorMapper;

    @Autowired
    public EditorService(EditorRepository editorRepository, EditorMapper editorMapper) {
        this.editorRepository = editorRepository;
        this.editorMapper = editorMapper;
    }

    public EditorResponseTo create(EditorRequestTo editorRequestTo) {
        Editor editor = editorMapper.toEntity(editorRequestTo);
        Editor savedEditor = editorRepository.save(editor);
        return editorMapper.toResponseTo(savedEditor);
    }

    public List<EditorResponseTo> findAll() {
        return editorRepository.findAll().stream()
            .map(editorMapper::toResponseTo)
            .toList();
    }

    public Optional<EditorResponseTo> findById(Long id) {
        return editorRepository.findById(id)
            .map(editorMapper::toResponseTo);
    }

    public Optional<EditorResponseTo> update(Long id, EditorRequestTo editorRequestTo) {
        if (!editorRepository.existsById(id)) {
            return Optional.empty();
        }
        Editor editor = editorMapper.toEntity(editorRequestTo);
        editor.setId(id);
        Editor updatedEditor = editorRepository.save(editor);
        return Optional.of(editorMapper.toResponseTo(updatedEditor));
    }

    public void deleteById(Long id) {
        editorRepository.deleteById(id);
    }

    @Mapper(componentModel = "spring")
    public interface EditorMapper {
        @Mapping(target = "articles", ignore = true)
        Editor toEntity(EditorRequestTo dto);

        EditorResponseTo toResponseTo(Editor entity);
    }
} 