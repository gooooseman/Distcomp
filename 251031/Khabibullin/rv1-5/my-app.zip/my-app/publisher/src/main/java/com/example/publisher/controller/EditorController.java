package com.example.publisher.controller;

import com.example.publisher.dto.EditorRequestTo;
import com.example.publisher.dto.EditorResponseTo;
import com.example.publisher.service.EditorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/editors")
public class EditorController {
    private final EditorService editorService;

    @Autowired
    public EditorController(EditorService editorService) {
        this.editorService = editorService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EditorResponseTo create(@Valid @RequestBody EditorRequestTo editorRequestTo) {
        return editorService.create(editorRequestTo);
    }

    @GetMapping
    public List<EditorResponseTo> findAll() {
        return editorService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<EditorResponseTo> findById(@PathVariable Long id) {
        return editorService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<EditorResponseTo> update(@PathVariable Long id,
                                                 @Valid @RequestBody EditorRequestTo editorRequestTo) {
        return editorService.update(id, editorRequestTo)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        editorService.deleteById(id);
    }
} 