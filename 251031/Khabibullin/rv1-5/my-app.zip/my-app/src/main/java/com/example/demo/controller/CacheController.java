package com.example.demo.controller;

import com.example.demo.dto.*;
import com.example.demo.service.CacheService;
import com.example.demo.service.EditorService;
import com.example.demo.service.ArticleService;
import com.example.demo.service.CommentService;
import com.example.demo.service.MarkService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0")
public class CacheController {
    private final EditorService editorService;
    private final ArticleService articleService;
    private final CommentService commentService;
    private final MarkService markService;
    private final CacheService cacheService;

    public CacheController(EditorService editorService,
                           ArticleService articleService,
                           CommentService commentService,
                           MarkService markService,
                           CacheService cacheService) {
        this.editorService = editorService;
        this.articleService = articleService;
        this.commentService = commentService;
        this.markService = markService;
        this.cacheService = cacheService;
    }

    // Editors endpoints
    @GetMapping("/editors")
    public List<EditorResponseTo> getAllEditors() {
        String cacheKey = "editors:all";
        @SuppressWarnings("unchecked")
        List<EditorResponseTo> cachedEditors = (List<EditorResponseTo>) cacheService.getCachedEntity(cacheKey);
        if (cachedEditors != null) {
            return cachedEditors;
        }
        List<EditorResponseTo> editors = editorService.getAllEditors();
        cacheService.cacheEntity(cacheKey, editors);
        return editors;
    }

    @GetMapping("/editors/{id}")
    public EditorResponseTo getEditorById(@PathVariable Long id) {
        String cacheKey = "editor:" + id;
        EditorResponseTo cachedEditor = (EditorResponseTo) cacheService.getCachedEntity(cacheKey);
        if (cachedEditor != null) {
            return cachedEditor;
        }
        EditorResponseTo editor = editorService.getEditorById(id);
        cacheService.cacheEntity(cacheKey, editor);
        return editor;
    }

    @PostMapping("/editors")
    @ResponseStatus(HttpStatus.CREATED)
    public EditorResponseTo createEditor(@RequestBody EditorRequestTo editorRequestTo) {
        EditorResponseTo editor = editorService.createEditor(editorRequestTo);
        cacheService.evictCache("editors:all");
        return editor;
    }

    @PutMapping("/editors/{id}")
    public EditorResponseTo updateEditor(@PathVariable Long id, @RequestBody EditorRequestTo editorRequestTo) {
        EditorResponseTo editor = editorService.updateEditor(id, editorRequestTo);
        cacheService.evictCache("editors:all");
        cacheService.evictCache("editor:" + id);
        return editor;
    }

    @DeleteMapping("/editors/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEditor(@PathVariable Long id) {
        editorService.deleteEditor(id);
        cacheService.evictCache("editors:all");
        cacheService.evictCache("editor:" + id);
    }

    // Articles endpoints
    @GetMapping("/articles")
    public List<ArticleResponseTo> getAllArticles() {
        String cacheKey = "articles:all";
        @SuppressWarnings("unchecked")
        List<ArticleResponseTo> cachedArticles = (List<ArticleResponseTo>) cacheService.getCachedEntity(cacheKey);
        if (cachedArticles != null) {
            return cachedArticles;
        }
        List<ArticleResponseTo> articles = articleService.getAllArticles();
        cacheService.cacheEntity(cacheKey, articles);
        return articles;
    }

    @GetMapping("/articles/{id}")
    public ArticleResponseTo getArticleById(@PathVariable Long id) {
        String cacheKey = "article:" + id;
        ArticleResponseTo cachedArticle = (ArticleResponseTo) cacheService.getCachedEntity(cacheKey);
        if (cachedArticle != null) {
            return cachedArticle;
        }
        ArticleResponseTo article = articleService.getArticleById(id);
        cacheService.cacheEntity(cacheKey, article);
        return article;
    }

    @PostMapping("/articles")
    @ResponseStatus(HttpStatus.CREATED)
    public ArticleResponseTo createArticle(@RequestBody ArticleRequestTo articleRequestTo) {
        ArticleResponseTo article = articleService.createArticle(articleRequestTo);
        cacheService.evictCache("articles:all");
        return article;
    }

    @PutMapping("/articles/{id}")
    public ArticleResponseTo updateArticle(@PathVariable Long id, @RequestBody ArticleRequestTo articleRequestTo) {
        ArticleResponseTo article = articleService.updateArticle(id, articleRequestTo);
        cacheService.evictCache("articles:all");
        cacheService.evictCache("article:" + id);
        return article;
    }

    @DeleteMapping("/articles/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteArticle(@PathVariable Long id) {
        articleService.deleteArticle(id);
        cacheService.evictCache("articles:all");
        cacheService.evictCache("article:" + id);
    }

    // Comments endpoints
    @GetMapping("/comments")
    public List<CommentResponseTo> getAllComments() {
        String cacheKey = "comments:all";
        @SuppressWarnings("unchecked")
        List<CommentResponseTo> cachedComments = (List<CommentResponseTo>) cacheService.getCachedEntity(cacheKey);
        if (cachedComments != null) {
            return cachedComments;
        }
        List<CommentResponseTo> comments = commentService.getAllComments();
        cacheService.cacheEntity(cacheKey, comments);
        return comments;
    }

    @GetMapping("/comments/{id}")
    public CommentResponseTo getCommentById(@PathVariable Long id) {
        String cacheKey = "comment:" + id;
        CommentResponseTo cachedComment = (CommentResponseTo) cacheService.getCachedEntity(cacheKey);
        if (cachedComment != null) {
            return cachedComment;
        }
        CommentResponseTo comment = commentService.getCommentById(id);
        cacheService.cacheEntity(cacheKey, comment);
        return comment;
    }

    @PostMapping("/comments")
    @ResponseStatus(HttpStatus.CREATED)
    public CommentResponseTo createComment(@RequestBody CommentRequestTo commentRequestTo) {
        CommentResponseTo comment = commentService.createComment(commentRequestTo);
        cacheService.evictCache("comments:all");
        return comment;
    }

    @PutMapping("/comments/{id}")
    public CommentResponseTo updateComment(@PathVariable Long id, @RequestBody CommentRequestTo commentRequestTo) {
        CommentResponseTo comment = commentService.updateComment(id, commentRequestTo);
        cacheService.evictCache("comments:all");
        cacheService.evictCache("comment:" + id);
        return comment;
    }

    @DeleteMapping("/comments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteComment(@PathVariable Long id) {
        commentService.deleteComment(id);
        cacheService.evictCache("comments:all");
        cacheService.evictCache("comment:" + id);
    }

    // Marks endpoints
    @GetMapping("/marks")
    public List<MarkResponseTo> getAllMarks() {
        String cacheKey = "marks:all";
        @SuppressWarnings("unchecked")
        List<MarkResponseTo> cachedMarks = (List<MarkResponseTo>) cacheService.getCachedEntity(cacheKey);
        if (cachedMarks != null) {
            return cachedMarks;
        }
        List<MarkResponseTo> marks = markService.getAllMarks();
        cacheService.cacheEntity(cacheKey, marks);
        return marks;
    }

    @GetMapping("/marks/{id}")
    public MarkResponseTo getMarkById(@PathVariable Long id) {
        String cacheKey = "mark:" + id;
        MarkResponseTo cachedMark = (MarkResponseTo) cacheService.getCachedEntity(cacheKey);
        if (cachedMark != null) {
            return cachedMark;
        }
        MarkResponseTo mark = markService.getMarkById(id);
        cacheService.cacheEntity(cacheKey, mark);
        return mark;
    }

    @PostMapping("/marks")
    @ResponseStatus(HttpStatus.CREATED)
    public MarkResponseTo createMark(@RequestBody MarkRequestTo markRequestTo) {
        MarkResponseTo mark = markService.createMark(markRequestTo);
        cacheService.evictCache("marks:all");
        return mark;
    }

    @PutMapping("/marks/{id}")
    public MarkResponseTo updateMark(@PathVariable Long id, @RequestBody MarkRequestTo markRequestTo) {
        MarkResponseTo mark = markService.updateMark(id, markRequestTo);
        cacheService.evictCache("marks:all");
        cacheService.evictCache("mark:" + id);
        return mark;
    }

    @DeleteMapping("/marks/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMark(@PathVariable Long id) {
        markService.deleteMark(id);
        cacheService.evictCache("marks:all");
        cacheService.evictCache("mark:" + id);
    }
}