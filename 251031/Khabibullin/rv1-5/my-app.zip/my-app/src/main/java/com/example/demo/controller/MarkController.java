package com.example.demo.controller;

import com.example.demo.dto.MarkRequestTo;
import com.example.demo.dto.MarkResponseTo;
import com.example.demo.service.MarkService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/marks")
public class MarkController {
    @Autowired
    private MarkService markService;

    @PostMapping
    public ResponseEntity<MarkResponseTo> createMark(@Valid @RequestBody MarkRequestTo markRequest) {
        try {
            MarkResponseTo response = markService.createMark(markRequest);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<MarkResponseTo>> getAllMarks() {
        List<MarkResponseTo> marks = markService.getAllMarks();
        return new ResponseEntity<>(marks, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MarkResponseTo> getMarkById(@PathVariable String id) {
        try {
            Long markId = Long.parseLong(id);
            MarkResponseTo mark = markService.getMarkById(markId);
            return mark != null ? new ResponseEntity<>(mark, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<MarkResponseTo> updateMark(@PathVariable String id, @Valid @RequestBody MarkRequestTo markRequest) {
        try {
            Long markId = Long.parseLong(id);
            markRequest.setId(markId);
            MarkResponseTo updatedMark = markService.updateMark(markId, markRequest);
            return updatedMark != null ? new ResponseEntity<>(updatedMark, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMark(@PathVariable String id) {
        try {
            Long markId = Long.parseLong(id);
            markService.deleteMark(markId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}