package com.example.discussion.repository;

import com.example.discussion.model.Comment;
import com.datastax.oss.driver.api.core.PagingState;
import com.datastax.oss.driver.api.core.cql.SimpleStatement;
import com.datastax.oss.driver.api.core.CqlSession;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CommentRepository {
    private final CqlSession session;
    private static final String TABLE_NAME = "tbl_comment";

    public CommentRepository(CqlSession session) {
        this.session = session;
    }

    public Comment save(Comment comment) {
        SimpleStatement statement = SimpleStatement.builder(
            "INSERT INTO " + TABLE_NAME + " (id, content, article_id, state) VALUES (?, ?, ?, ?)")
            .addPositionalValues(comment.getId(), comment.getContent(), comment.getArticleId(), comment.getState())
            .build();
        session.execute(statement);
        return comment;
    }

    public Optional<Comment> findById(Long id) {
        SimpleStatement statement = SimpleStatement.builder(
            "SELECT * FROM " + TABLE_NAME + " WHERE id = ?")
            .addPositionalValue(id)
            .build();
        var result = session.execute(statement);
        var row = result.one();
        if (row == null) {
            return Optional.empty();
        }
        return Optional.of(new Comment(
            row.getLong("id"),
            row.getString("content"),
            row.getLong("article_id"),
            row.getString("state")
        ));
    }

    public List<Comment> findByArticleId(Long articleId) {
        SimpleStatement statement = SimpleStatement.builder(
            "SELECT * FROM " + TABLE_NAME + " WHERE article_id = ?")
            .addPositionalValue(articleId)
            .build();
        var result = session.execute(statement);
        return result.all().stream()
            .map(row -> new Comment(
                row.getLong("id"),
                row.getString("content"),
                row.getLong("article_id"),
                row.getString("state")
            ))
            .toList();
    }

    public void deleteById(Long id) {
        SimpleStatement statement = SimpleStatement.builder(
            "DELETE FROM " + TABLE_NAME + " WHERE id = ?")
            .addPositionalValue(id)
            .build();
        session.execute(statement);
    }

    public List<Comment> findAll() {
        SimpleStatement statement = SimpleStatement.builder(
            "SELECT * FROM " + TABLE_NAME)
            .build();
        var result = session.execute(statement);
        return result.all().stream()
            .map(row -> new Comment(
                row.getLong("id"),
                row.getString("content"),
                row.getLong("article_id"),
                row.getString("state")
            ))
            .toList();
    }
} 