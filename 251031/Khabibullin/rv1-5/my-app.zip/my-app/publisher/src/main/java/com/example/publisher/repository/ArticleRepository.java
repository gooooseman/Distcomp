package com.example.publisher.repository;

import com.example.publisher.model.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {
    List<Article> findByEditorId(Long editorId);
    List<Article> findByMarksName(String markName);
    List<Article> findByMarksIdAndEditorLogin(Long markId, String editorLogin);
} 