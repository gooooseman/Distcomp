package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
public class Mark {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne
    @JoinColumn(name = "editor_id", nullable = false)
    private Editor editor;

    @ManyToOne
    @JoinColumn(name = "article_id", nullable = false)
    private Article article;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Editor getEditor() { return editor; }
    public void setEditor(Editor editor) { this.editor = editor; }
    public Article getArticle() { return article; }
    public void setArticle(Article article) { this.article = article; }
}