package com.example.demo.service;

import com.example.demo.dto.EditorRequestTo;
import com.example.demo.dto.EditorResponseTo;
import com.example.demo.entity.Editor;
import com.example.demo.repository.EditorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EditorService {
    @Autowired
    private EditorRepository editorRepository;

    public EditorResponseTo createEditor(EditorRequestTo editorRequest) {
        if (editorRequest.getLogin() == null || editorRequest.getPassword() == null) {
            throw new IllegalArgumentException("Login and password are required");
        }
        Editor editor = new Editor();
        editor.setLogin(editorRequest.getLogin());
        editor.setPassword(editorRequest.getPassword());
        editor.setFirstname(editorRequest.getFirstname());
        editor.setLastname(editorRequest.getLastname());
        Editor savedEditor = editorRepository.save(editor);
        return mapToResponse(savedEditor);
    }

    public List<EditorResponseTo> getAllEditors() {
        return editorRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public EditorResponseTo getEditorById(Long id) {
        return editorRepository.findById(id)
                .map(this::mapToResponse)
                .orElse(null);
    }

    public EditorResponseTo updateEditor(Long id, EditorRequestTo editorRequest) {
        if (editorRequest.getLogin() == null || editorRequest.getPassword() == null) {
            throw new IllegalArgumentException("Login and password are required");
        }
        return editorRepository.findById(id)
                .map(editor -> {
                    editor.setLogin(editorRequest.getLogin());
                    editor.setPassword(editorRequest.getPassword());
                    editor.setFirstname(editorRequest.getFirstname());
                    editor.setLastname(editorRequest.getLastname());
                    Editor updatedEditor = editorRepository.save(editor);
                    return mapToResponse(updatedEditor);
                })
                .orElse(null);
    }

    public void deleteEditor(Long id) {
        if (!editorRepository.existsById(id)) {
            throw new IllegalArgumentException("Editor not found");
        }
        editorRepository.deleteById(id);
    }

    private EditorResponseTo mapToResponse(Editor editor) {
        EditorResponseTo response = new EditorResponseTo();
        response.setId(editor.getId());
        response.setLogin(editor.getLogin());
        response.setFirstname(editor.getFirstname());
        response.setLastname(editor.getLastname());
        return response;
    }
}