# RESTful Application

Многомодульное RESTful приложение с использованием различных технологий баз данных.

## Структура проекта

Проект состоит из двух модулей:
- `publisher` - модуль для работы с редакторами, статьями и метками (PostgreSQL + Redis)
- `discussion` - модуль для работы с комментариями (Cassandra)

## Требования

- Java 17
- Maven
- PostgreSQL
- Redis
- Cassandra
- Kafka

## Настройка окружения

### PostgreSQL
```bash
docker run --name postgres -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=distcomp -p 5432:5432 -d postgres
```

### Redis
```bash
docker run --name redis -p 6379:6379 -d redis
```

### Cassandra
```bash
docker run --name cassandra -p 9042:9042 -d cassandra
```

### Kafka
```bash
docker-compose up -d
```

## Сборка и запуск

1. Собрать проект:
```bash
mvn clean package
```

2. Запустить модуль publisher:
```bash
java -jar publisher/target/publisher-0.0.1-SNAPSHOT.jar
```

3. Запустить модуль discussion:
```bash
java -jar discussion/target/discussion-0.0.1-SNAPSHOT.jar
```

## API Endpoints

### Publisher Module (Port 24110)

#### Editors
- POST /api/v1.0/editors - Создать редактора
- GET /api/v1.0/editors - Получить всех редакторов
- GET /api/v1.0/editors/{id} - Получить редактора по ID
- PUT /api/v1.0/editors/{id} - Обновить редактора
- DELETE /api/v1.0/editors/{id} - Удалить редактора

#### Articles
- POST /api/v1.0/articles - Создать статью
- GET /api/v1.0/articles - Получить все статьи
- GET /api/v1.0/articles/{id} - Получить статью по ID
- PUT /api/v1.0/articles/{id} - Обновить статью
- DELETE /api/v1.0/articles/{id} - Удалить статью
- GET /api/v1.0/articles/editor/{editorId} - Получить статьи редактора
- GET /api/v1.0/articles/mark/{markName} - Получить статьи по метке
- GET /api/v1.0/articles/mark/{markId}/editor/{editorLogin} - Получить статьи по метке и логину редактора

#### Marks
- POST /api/v1.0/marks - Создать метку
- GET /api/v1.0/marks - Получить все метки
- GET /api/v1.0/marks/{id} - Получить метку по ID
- PUT /api/v1.0/marks/{id} - Обновить метку
- DELETE /api/v1.0/marks/{id} - Удалить метку

### Discussion Module (Port 24130)

#### Comments
- POST /api/v1.0/comments - Создать комментарий
- GET /api/v1.0/comments - Получить все комментарии
- GET /api/v1.0/comments/{id} - Получить комментарий по ID
- GET /api/v1.0/comments/article/{articleId} - Получить комментарии к статье
- PUT /api/v1.0/comments/{id} - Обновить комментарий
- DELETE /api/v1.0/comments/{id} - Удалить комментарий
- PUT /api/v1.0/comments/{id}/moderate - Модерировать комментарий

## Технологии

- Java 17
- Spring Boot
- Spring Data JPA
- Spring Data Redis
- Spring Data Cassandra
- Spring Kafka
- Liquibase
- MapStruct
- Lombok
- PostgreSQL
- Redis
- Cassandra
- Kafka 