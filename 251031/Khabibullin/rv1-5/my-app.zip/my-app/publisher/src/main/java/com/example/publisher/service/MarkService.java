package com.example.publisher.service;

import com.example.publisher.dto.MarkRequestTo;
import com.example.publisher.dto.MarkResponseTo;
import com.example.publisher.model.Mark;
import com.example.publisher.repository.MarkRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class MarkService {
    private final MarkRepository markRepository;
    private final MarkMapper markMapper;

    @Autowired
    public MarkService(MarkRepository markRepository, MarkMapper markMapper) {
        this.markRepository = markRepository;
        this.markMapper = markMapper;
    }

    public MarkResponseTo create(MarkRequestTo markRequestTo) {
        Mark mark = markMapper.toEntity(markRequestTo);
        Mark savedMark = markRepository.save(mark);
        return markMapper.toResponseTo(savedMark);
    }

    public List<MarkResponseTo> findAll() {
        return markRepository.findAll().stream()
            .map(markMapper::toResponseTo)
            .toList();
    }

    public Optional<MarkResponseTo> findById(Long id) {
        return markRepository.findById(id)
            .map(markMapper::toResponseTo);
    }

    public Optional<MarkResponseTo> update(Long id, MarkRequestTo markRequestTo) {
        if (!markRepository.existsById(id)) {
            return Optional.empty();
        }
        Mark mark = markMapper.toEntity(markRequestTo);
        mark.setId(id);
        Mark updatedMark = markRepository.save(mark);
        return Optional.of(markMapper.toResponseTo(updatedMark));
    }

    public void deleteById(Long id) {
        markRepository.deleteById(id);
    }

    @Mapper(componentModel = "spring")
    public interface MarkMapper {
        @Mapping(target = "articles", ignore = true)
        Mark toEntity(MarkRequestTo dto);

        MarkResponseTo toResponseTo(Mark entity);
    }
} 