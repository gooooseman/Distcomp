package com.example.discussion.controller;

import com.example.discussion.dto.CommentRequestTo;
import com.example.discussion.dto.CommentResponseTo;
import com.example.discussion.service.CommentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/comments")
public class CommentController {
    private final CommentService commentService;

    @Autowired
    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CommentResponseTo create(@Valid @RequestBody CommentRequestTo commentRequestTo) {
        return commentService.create(commentRequestTo);
    }

    @GetMapping
    public List<CommentResponseTo> findAll() {
        return commentService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CommentResponseTo> findById(@PathVariable Long id) {
        return commentService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/article/{articleId}")
    public List<CommentResponseTo> findByArticleId(@PathVariable Long articleId) {
        return commentService.findByArticleId(articleId);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CommentResponseTo> update(@PathVariable Long id,
                                                  @Valid @RequestBody CommentRequestTo commentRequestTo) {
        return commentService.update(id, commentRequestTo)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        commentService.deleteById(id);
    }

    @PutMapping("/{id}/moderate")
    public ResponseEntity<Void> moderateComment(@PathVariable Long id,
                                              @RequestParam String state) {
        if (!state.equals("APPROVE") && !state.equals("DECLINE")) {
            return ResponseEntity.badRequest().build();
        }
        commentService.moderateComment(id, state);
        return ResponseEntity.ok().build();
    }
} 