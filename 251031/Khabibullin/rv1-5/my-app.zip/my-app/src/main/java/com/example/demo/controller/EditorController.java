package com.example.demo.controller;

import com.example.demo.dto.EditorRequestTo;
import com.example.demo.dto.EditorResponseTo;
import com.example.demo.service.EditorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/editors")
public class EditorController {
    @Autowired
    private EditorService editorService;

    @PostMapping
    public ResponseEntity<EditorResponseTo> createEditor(@RequestBody EditorRequestTo editorRequest) {
        try {
            EditorResponseTo response = editorService.createEditor(editorRequest);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<EditorResponseTo>> getAllEditors() {
        List<EditorResponseTo> editors = editorService.getAllEditors();
        return new ResponseEntity<>(editors, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EditorResponseTo> getEditorById(@PathVariable Long id) {
        EditorResponseTo editor = editorService.getEditorById(id);
        return editor != null ? new ResponseEntity<>(editor, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EditorResponseTo> updateEditor(@PathVariable Long id, @RequestBody EditorRequestTo editorRequest) {
        try {
            EditorResponseTo updatedEditor = editorService.updateEditor(id, editorRequest);
            return updatedEditor != null ? new ResponseEntity<>(updatedEditor, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEditor(@PathVariable Long id) {
        try {
            editorService.deleteEditor(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}