package com.example.discussion.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentResponseTo {
    private Long id;
    private String content;
    private Long articleId;
    private String state;
} 