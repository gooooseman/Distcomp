package com.example.publisher.controller;

import com.example.publisher.dto.MarkRequestTo;
import com.example.publisher.dto.MarkResponseTo;
import com.example.publisher.service.MarkService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/marks")
public class MarkController {
    private final MarkService markService;

    @Autowired
    public MarkController(MarkService markService) {
        this.markService = markService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MarkResponseTo create(@Valid @RequestBody MarkRequestTo markRequestTo) {
        return markService.create(markRequestTo);
    }

    @GetMapping
    public List<MarkResponseTo> findAll() {
        return markService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MarkResponseTo> findById(@PathVariable Long id) {
        return markService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<MarkResponseTo> update(@PathVariable Long id,
                                               @Valid @RequestBody MarkRequestTo markRequestTo) {
        return markService.update(id, markRequestTo)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        markService.deleteById(id);
    }
} 