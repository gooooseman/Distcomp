package com.example.discussion.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;
import org.springframework.data.cassandra.core.mapping.Column;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table("comment")
public class Comment {
    @PrimaryKey
    private Long id;

    @Column
    private String content;

    @Column("article_id")
    private Long articleId;

    @Column
    private String state; // PENDING, APPROVE, DECLINE

    @Column
    private LocalDateTime created;

    @Column
    private LocalDateTime modified;
} 