package com.example.publisher.service;

import com.example.publisher.dto.ArticleRequestTo;
import com.example.publisher.dto.ArticleResponseTo;
import com.example.publisher.model.Article;
import com.example.publisher.model.Editor;
import com.example.publisher.model.Mark;
import com.example.publisher.repository.ArticleRepository;
import com.example.publisher.repository.EditorRepository;
import com.example.publisher.repository.MarkRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class ArticleService {
    private final ArticleRepository articleRepository;
    private final EditorRepository editorRepository;
    private final MarkRepository markRepository;
    private final ArticleMapper articleMapper;

    @Autowired
    public ArticleService(ArticleRepository articleRepository,
                         EditorRepository editorRepository,
                         MarkRepository markRepository,
                         ArticleMapper articleMapper) {
        this.articleRepository = articleRepository;
        this.editorRepository = editorRepository;
        this.markRepository = markRepository;
        this.articleMapper = articleMapper;
    }

    public ArticleResponseTo create(ArticleRequestTo articleRequestTo) {
        Article article = articleMapper.toEntity(articleRequestTo);
        Editor editor = editorRepository.findById(articleRequestTo.getEditorId())
            .orElseThrow(() -> new RuntimeException("Editor not found"));
        article.setEditor(editor);

        if (articleRequestTo.getMarkIds() != null) {
            List<Mark> marks = articleRequestTo.getMarkIds().stream()
                .map(markId -> markRepository.findById(markId)
                    .orElseThrow(() -> new RuntimeException("Mark not found: " + markId)))
                .collect(Collectors.toList());
            article.setMarks(marks);
        }

        Article savedArticle = articleRepository.save(article);
        return articleMapper.toResponseTo(savedArticle);
    }

    public List<ArticleResponseTo> findAll() {
        return articleRepository.findAll().stream()
            .map(articleMapper::toResponseTo)
            .toList();
    }

    public Optional<ArticleResponseTo> findById(Long id) {
        return articleRepository.findById(id)
            .map(articleMapper::toResponseTo);
    }

    public Optional<ArticleResponseTo> update(Long id, ArticleRequestTo articleRequestTo) {
        if (!articleRepository.existsById(id)) {
            return Optional.empty();
        }

        Article article = articleMapper.toEntity(articleRequestTo);
        article.setId(id);

        Editor editor = editorRepository.findById(articleRequestTo.getEditorId())
            .orElseThrow(() -> new RuntimeException("Editor not found"));
        article.setEditor(editor);

        if (articleRequestTo.getMarkIds() != null) {
            List<Mark> marks = articleRequestTo.getMarkIds().stream()
                .map(markId -> markRepository.findById(markId)
                    .orElseThrow(() -> new RuntimeException("Mark not found: " + markId)))
                .collect(Collectors.toList());
            article.setMarks(marks);
        }

        Article updatedArticle = articleRepository.save(article);
        return Optional.of(articleMapper.toResponseTo(updatedArticle));
    }

    public void deleteById(Long id) {
        articleRepository.deleteById(id);
    }

    public List<ArticleResponseTo> findByEditorId(Long editorId) {
        return articleRepository.findByEditorId(editorId).stream()
            .map(articleMapper::toResponseTo)
            .toList();
    }

    public List<ArticleResponseTo> findByMarkName(String markName) {
        return articleRepository.findByMarksName(markName).stream()
            .map(articleMapper::toResponseTo)
            .toList();
    }

    public List<ArticleResponseTo> findByMarkIdAndEditorLogin(Long markId, String editorLogin) {
        return articleRepository.findByMarksIdAndEditorLogin(markId, editorLogin).stream()
            .map(articleMapper::toResponseTo)
            .toList();
    }

    @Mapper(componentModel = "spring", uses = {EditorService.EditorMapper.class, MarkService.MarkMapper.class})
    public interface ArticleMapper {
        @Mapping(target = "editor", ignore = true)
        @Mapping(target = "marks", ignore = true)
        Article toEntity(ArticleRequestTo dto);

        ArticleResponseTo toResponseTo(Article entity);
    }
} 