package com.example.publisher.controller;

import com.example.publisher.dto.ArticleRequestTo;
import com.example.publisher.dto.ArticleResponseTo;
import com.example.publisher.service.ArticleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/articles")
public class ArticleController {
    private final ArticleService articleService;

    @Autowired
    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ArticleResponseTo create(@Valid @RequestBody ArticleRequestTo articleRequestTo) {
        return articleService.create(articleRequestTo);
    }

    @GetMapping
    public List<ArticleResponseTo> findAll() {
        return articleService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArticleResponseTo> findById(@PathVariable Long id) {
        return articleService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<ArticleResponseTo> update(@PathVariable Long id,
                                                  @Valid @RequestBody ArticleRequestTo articleRequestTo) {
        return articleService.update(id, articleRequestTo)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        articleService.deleteById(id);
    }

    @GetMapping("/editor/{editorId}")
    public List<ArticleResponseTo> findByEditorId(@PathVariable Long editorId) {
        return articleService.findByEditorId(editorId);
    }

    @GetMapping("/mark/name/{markName}")
    public List<ArticleResponseTo> findByMarkName(@PathVariable String markName) {
        return articleService.findByMarkName(markName);
    }

    @GetMapping("/mark/{markId}/editor/{editorLogin}")
    public List<ArticleResponseTo> findByMarkIdAndEditorLogin(@PathVariable Long markId,
                                                            @PathVariable String editorLogin) {
        return articleService.findByMarkIdAndEditorLogin(markId, editorLogin);
    }
} 