package com.example.demo.service;

import com.example.demo.dto.MarkRequestTo;
import com.example.demo.dto.MarkResponseTo;
import com.example.demo.entity.Mark;
import com.example.demo.entity.Editor;
import com.example.demo.entity.Article;
import com.example.demo.repository.MarkRepository;
import com.example.demo.repository.EditorRepository;
import com.example.demo.repository.ArticleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MarkService {
    private static final Logger logger = LoggerFactory.getLogger(MarkService.class);

    @Autowired
    private MarkRepository markRepository;
    @Autowired
    private EditorRepository editorRepository;
    @Autowired
    private ArticleRepository articleRepository;

    public MarkResponseTo createMark(MarkRequestTo markRequest) {
        logger.info("Creating mark with request: {}", markRequest);
        Editor editor = editorRepository.findById(markRequest.getEditorId())
                .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
        Article article = articleRepository.findById(markRequest.getArticleId())
                .orElseThrow(() -> new IllegalArgumentException("Article not found"));
        Mark mark = new Mark();
        mark.setName(markRequest.getName());
        mark.setEditor(editor);
        mark.setArticle(article);
        Mark savedMark = markRepository.save(mark);
        return mapToResponse(savedMark);
    }

    public List<MarkResponseTo> getAllMarks() {
        try {
            return markRepository.findAll().stream()
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Failed to fetch marks", e);
            throw new IllegalStateException("Failed to fetch marks: " + e.getMessage());
        }
    }

    public MarkResponseTo getMarkById(Long id) {
        return markRepository.findById(id)
                .map(this::mapToResponse)
                .orElse(null);
    }

    public MarkResponseTo updateMark(Long id, MarkRequestTo markRequest) {
        return markRepository.findById(id)
                .map(mark -> {
                    Editor editor = editorRepository.findById(markRequest.getEditorId())
                            .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
                    Article article = articleRepository.findById(markRequest.getArticleId())
                            .orElseThrow(() -> new IllegalArgumentException("Article not found"));
                    mark.setName(markRequest.getName());
                    mark.setEditor(editor);
                    mark.setArticle(article);
                    Mark updatedMark = markRepository.save(mark);
                    return mapToResponse(updatedMark);
                })
                .orElse(null);
    }

    public void deleteMark(Long id) {
        if (!markRepository.existsById(id)) {
            throw new IllegalArgumentException("Mark not found");
        }
        markRepository.deleteById(id);
    }

    private MarkResponseTo mapToResponse(Mark mark) {
        MarkResponseTo response = new MarkResponseTo();
        response.setId(mark.getId());
        response.setName(mark.getName());
        response.setEditorId(mark.getEditor().getId());
        response.setArticleId(mark.getArticle().getId());
        return response;
    }
}