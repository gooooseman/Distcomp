package com.example.demo.controller;

import com.example.demo.dto.ArticleRequestTo;
import com.example.demo.dto.ArticleResponseTo;
import com.example.demo.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/articles")
public class ArticleController {
    @Autowired
    private ArticleService articleService;

    @PostMapping
    public ResponseEntity<ArticleResponseTo> createArticle(@RequestBody ArticleRequestTo articleRequest) {
        ArticleResponseTo response = articleService.createArticle(articleRequest);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ArticleResponseTo>> getAllArticles() {
        List<ArticleResponseTo> articles = articleService.getAllArticles();
        return new ResponseEntity<>(articles, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArticleResponseTo> getArticleById(@PathVariable Long id) {
        ArticleResponseTo article = articleService.getArticleById(id);
        return article != null ? new ResponseEntity<>(article, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ArticleResponseTo> updateArticle(@PathVariable Long id, @RequestBody ArticleRequestTo articleRequest) {
        ArticleResponseTo updatedArticle = articleService.updateArticle(id, articleRequest);
        return updatedArticle != null ? new ResponseEntity<>(updatedArticle, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArticle(@PathVariable Long id) {
        try {
            articleService.deleteArticle(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}