package com.example.demo.service;

import com.example.demo.dto.CommentRequestTo;
import com.example.demo.dto.CommentResponseTo;
import com.example.demo.entity.Comment;
import com.example.demo.entity.Editor;
import com.example.demo.entity.Article;
import com.example.demo.repository.CommentRepository;
import com.example.demo.repository.EditorRepository;
import com.example.demo.repository.ArticleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {
    private static final Logger logger = LoggerFactory.getLogger(CommentService.class);

    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private EditorRepository editorRepository;
    @Autowired
    private ArticleRepository articleRepository;

    public CommentResponseTo createComment(CommentRequestTo commentRequest) {
        logger.info("Creating comment with request: {}", commentRequest);
        Editor editor = editorRepository.findById(commentRequest.getEditorId())
                .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
        Article article = articleRepository.findById(commentRequest.getArticleId())
                .orElseThrow(() -> new IllegalArgumentException("Article not found"));
        Comment comment = new Comment();
        comment.setText(commentRequest.getContent());
        comment.setEditor(editor);
        comment.setArticle(article);
        Comment savedComment = commentRepository.save(comment);
        return mapToResponse(savedComment);
    }

    public List<CommentResponseTo> getAllComments() {
        return commentRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public CommentResponseTo getCommentById(Long id) {
        return commentRepository.findById(id)
                .map(this::mapToResponse)
                .orElse(null);
    }

    public CommentResponseTo updateComment(Long id, CommentRequestTo commentRequest) {
        return commentRepository.findById(id)
                .map(comment -> {
                    Editor editor = editorRepository.findById(commentRequest.getEditorId())
                            .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
                    Article article = articleRepository.findById(commentRequest.getArticleId())
                            .orElseThrow(() -> new IllegalArgumentException("Article not found"));
                    comment.setText(commentRequest.getContent());
                    comment.setEditor(editor);
                    comment.setArticle(article);
                    Comment updatedComment = commentRepository.save(comment);
                    return mapToResponse(updatedComment);
                })
                .orElse(null);
    }

    public void deleteComment(Long id) {
        if (!commentRepository.existsById(id)) {
            throw new IllegalArgumentException("Comment not found");
        }
        commentRepository.deleteById(id);
    }

    private CommentResponseTo mapToResponse(Comment comment) {
        CommentResponseTo response = new CommentResponseTo();
        response.setId(comment.getId());
        response.setContent(comment.getText());
        response.setEditorId(comment.getEditor().getId());
        response.setArticleId(comment.getArticle().getId());
        return response;
    }
}