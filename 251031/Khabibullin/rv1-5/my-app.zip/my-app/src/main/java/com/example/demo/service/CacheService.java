package com.example.demo.service;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class CacheService {
    private final RedisTemplate<String, Object> redisTemplate;
    private static final long CACHE_TTL = 60; // 60 секунд

    public CacheService(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public void cacheEntity(String key, Object entity) {
        redisTemplate.opsForValue().set(key, entity, CACHE_TTL, TimeUnit.SECONDS);
    }

    public Object getCachedEntity(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public void evictCache(String key) {
        redisTemplate.delete(key);
    }
}