package com.example.demo.service;

import com.example.demo.dto.ArticleRequestTo;
import com.example.demo.dto.ArticleResponseTo;
import com.example.demo.entity.Article;
import com.example.demo.entity.Editor;
import com.example.demo.repository.ArticleRepository;
import com.example.demo.repository.EditorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticleService {
    @Autowired
    private ArticleRepository articleRepository;
    @Autowired
    private EditorRepository editorRepository;

    public ArticleResponseTo createArticle(ArticleRequestTo articleRequest) {
        Editor editor = editorRepository.findById(articleRequest.getEditorId())
                .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
        Article article = new Article();
        article.setTitle(articleRequest.getTitle());
        article.setContent(articleRequest.getContent());
        article.setEditor(editor);
        Article savedArticle = articleRepository.save(article);
        return mapToResponse(savedArticle);
    }

    public List<ArticleResponseTo> getAllArticles() {
        return articleRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public ArticleResponseTo getArticleById(Long id) {
        return articleRepository.findById(id)
                .map(this::mapToResponse)
                .orElse(null);
    }

    public ArticleResponseTo updateArticle(Long id, ArticleRequestTo articleRequest) {
        return articleRepository.findById(id)
                .map(article -> {
                    Editor editor = editorRepository.findById(articleRequest.getEditorId())
                            .orElseThrow(() -> new IllegalArgumentException("Editor not found"));
                    article.setTitle(articleRequest.getTitle());
                    article.setContent(articleRequest.getContent());
                    article.setEditor(editor);
                    Article updatedArticle = articleRepository.save(article);
                    return mapToResponse(updatedArticle);
                })
                .orElse(null);
    }

    public void deleteArticle(Long id) {
        if (!articleRepository.existsById(id)) {
            throw new IllegalArgumentException("Article not found");
        }
        articleRepository.deleteById(id);
    }

    private ArticleResponseTo mapToResponse(Article article) {
        ArticleResponseTo response = new ArticleResponseTo();
        response.setId(article.getId());
        response.setTitle(article.getTitle());
        response.setContent(article.getContent());
        response.setEditorId(article.getEditor().getId());
        return response;
    }
}